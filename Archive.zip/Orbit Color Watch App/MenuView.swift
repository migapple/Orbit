import SwiftUI

struct MenuView: View {
    @ObservedObject var game: OrbitGame

    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                HStack {
                    Text("ORBIT")
                        .font(.system(.headline, design: .rounded).weight(.bold))
                        .tracking(2)
                        .foregroundStyle(Palette.gold)
                    Spacer()
                    Button(game.lang.flag) { game.lang = game.lang.toggled }
                        .buttonStyle(.plain)
                        .font(.title3)
                        .accessibilityLabel(game.lang == .fr ? "English" : "Français")
                }

                // Anneau qui tourne lentement en décor
                TimelineView(.animation) { context in
                    let t = context.date.timeIntervalSinceReferenceDate
                    RingView(ringAngle: (t * 25).truncatingRemainder(dividingBy: 360),
                             balls: [], size: 86)
                }
                .frame(height: 86)

                Text("\(game.t(.best)) \(game.best)")
                    .font(.caption)
                    .monospacedDigit()
                    .foregroundStyle(Palette.muted)

                Button {
                    game.start()
                } label: {
                    Text(game.t(.play)).bold().frame(maxWidth: .infinity)
                }
                .tint(Palette.gold)

                Text(game.t(.hint))
                    .font(.system(size: 12))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(Palette.muted)
                Text(game.t(.pauseHint))
                    .font(.system(size: 11))
                    .foregroundStyle(Palette.muted.opacity(0.8))
            }
            .padding(.horizontal, 6)
        }
        .background(Color.black.ignoresSafeArea())
    }
}
