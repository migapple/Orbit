import SwiftUI

@main
struct OrbitApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}

/// Palette du catalogue : encre, or, parchemin + 4 couleurs de segments
/// (contrastées en luminosité, pas seulement en teinte).
enum Palette {
    static let ink       = Color(red: 7/255,   green: 5/255,   blue: 16/255)
    static let gold      = Color(red: 201/255, green: 164/255, blue: 92/255)
    static let parchment = Color(red: 238/255, green: 226/255, blue: 200/255)
    static let muted     = Color(red: 154/255, green: 144/255, blue: 128/255)
    static let track     = Color(red: 21/255,  green: 19/255,  blue: 32/255)

    static let teal = Color(red: 47/255,  green: 165/255, blue: 151/255)
    static let rose = Color(red: 224/255, green: 101/255, blue: 123/255)
    static let blue = Color(red: 79/255,  green: 127/255, blue: 224/255)

    static let segments: [Color] = [gold, teal, rose, blue]
}

/// Écran racine : menu ou partie.
struct RootView: View {
    @StateObject private var game = OrbitGame()

    var body: some View {
        Group {
            if game.state == .menu {
                MenuView(game: game)
            } else {
                GameView(game: game)
            }
        }
    }
}
