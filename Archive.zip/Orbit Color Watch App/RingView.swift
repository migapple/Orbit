import SwiftUI

/// Dessin de l'anneau à 4 couleurs, du moyeu central et des balles.
/// Même convention d'angle que OrbitGame (0° = droite, sens horaire à l'écran).
struct RingView: View {
    let ringAngle: Double
    let balls: [Ball]
    let size: CGFloat

    var body: some View {
        Canvas { ctx, canvasSize in
            let c = CGPoint(x: canvasSize.width / 2, y: canvasSize.height / 2)
            let lineWidth = size * 0.09
            let radius = size / 2 - lineWidth / 2 - 1

            // Piste sombre sous l'anneau
            var track = Path()
            track.addArc(center: c, radius: radius, startAngle: .zero,
                         endAngle: .degrees(360), clockwise: false)
            ctx.stroke(track, with: .color(Palette.track), lineWidth: lineWidth + 6)

            // Segments colorés
            let count = OrbitGame.segmentCount
            let seg = 360.0 / Double(count)
            let gap = 5.0
            for i in 0..<count {
                let start = ringAngle + Double(i) * seg + gap / 2
                var arc = Path()
                arc.addArc(center: c, radius: radius,
                           startAngle: .degrees(start),
                           endAngle: .degrees(start + seg - gap),
                           clockwise: false)
                ctx.stroke(arc, with: .color(Palette.segments[i]),
                           style: StrokeStyle(lineWidth: lineWidth, lineCap: .butt))
            }

            // Moyeu central
            let hubR = size * 0.07
            ctx.fill(circle(c, hubR), with: .color(Palette.ink))
            ctx.stroke(circle(c, hubR), with: .color(Color.white.opacity(0.12)), lineWidth: 1)
            ctx.fill(circle(c, hubR * 0.25), with: .color(Palette.gold))

            // Balles et traînées
            let ballR = size * 0.05
            let travel = radius - lineWidth / 2 - ballR
            for ball in balls {
                let rad = ball.angle * .pi / 180
                let dx = CGFloat(cos(rad)), dy = CGFloat(sin(rad))
                let color = Palette.segments[ball.colorIndex]

                for k in 1...3 {
                    let d = CGFloat(max(0, ball.distance - Double(k) * 0.06))
                    let p = CGPoint(x: c.x + dx * travel * d, y: c.y + dy * travel * d)
                    let r = ballR * (1 - CGFloat(k) * 0.22)
                    ctx.fill(circle(p, r), with: .color(color.opacity(0.5 - Double(k) * 0.13)))
                }

                let d = CGFloat(min(ball.distance, 1))
                let p = CGPoint(x: c.x + dx * travel * d, y: c.y + dy * travel * d)
                ctx.fill(circle(p, ballR), with: .color(color))
                let shine = CGPoint(x: p.x - ballR * 0.3, y: p.y - ballR * 0.3)
                ctx.fill(circle(shine, ballR * 0.3), with: .color(Color.white.opacity(0.55)))
            }
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }

    private func circle(_ center: CGPoint, _ r: CGFloat) -> Path {
        Path(ellipseIn: CGRect(x: center.x - r, y: center.y - r, width: r * 2, height: r * 2))
    }
}
