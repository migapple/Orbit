import SwiftUI
import Combine

struct GameView: View {
    @ObservedObject var game: OrbitGame

    @State private var crown = 0.0
    @State private var lastCrown = 0.0
    @State private var lastTick = Date()
    @Environment(\.scenePhase) private var scenePhase

    /// Degrés de rotation de l'anneau par unité de Couronne (à ajuster au ressenti).
    private let degreesPerCrownUnit = 6.0
    private let timer = Timer.publish(every: 1.0 / 60, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            ZStack {
                // Score en filigrane au centre
                Text("\(game.score)")
                    .font(.system(size: size * 0.24, weight: .bold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(Palette.parchment.opacity(0.22))

                RingView(ringAngle: game.ringAngle, balls: game.balls, size: size)

                VStack {
                    Spacer()
                    LivesView(lives: game.lives)
                        .padding(.bottom, 12)
                }

                overlay
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .ignoresSafeArea()
        .background(Color.black.ignoresSafeArea())
        .toolbar(.hidden, for: .navigationBar)
        .focusable()
        .digitalCrownRotation($crown, from: -1_000_000, through: 1_000_000, by: 0.1,
                              sensitivity: .medium, isContinuous: true,
                              isHapticFeedbackEnabled: false)
        .onChange(of: crown) { _, value in
            let delta = value - lastCrown
            lastCrown = value
            game.rotate(by: delta * degreesPerCrownUnit)
        }
        .onReceive(timer) { now in
            let dt = min(now.timeIntervalSince(lastTick), 0.05)
            lastTick = now
            game.tick(dt)
        }
        .onLongPressGesture(minimumDuration: 0.5) {
            if game.state == .playing { game.pause() }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { game.pause() }
        }
        .onAppear {
            lastTick = Date()
            lastCrown = crown
        }
    }

    @ViewBuilder
    private var overlay: some View {
        switch game.state {
        case .paused:
            PauseOverlay(game: game)
        case .over:
            GameOverOverlay(game: game)
        default:
            EmptyView()
        }
    }
}

struct LivesView: View {
    let lives: Int

    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<OrbitGame.maxLives, id: \.self) { i in
                Circle()
                    .fill(i < lives ? Palette.gold : Palette.track)
                    .frame(width: 7, height: 7)
            }
        }
        .accessibilityElement()
        .accessibilityLabel("\(lives)")
    }
}

struct PauseOverlay: View {
    @ObservedObject var game: OrbitGame

    var body: some View {
        ZStack {
            Color.black.opacity(0.85).ignoresSafeArea()
                .onTapGesture { game.resume() }
            VStack(spacing: 8) {
                HStack {
                    Spacer()
                    Button(game.lang.flag) { game.lang = game.lang.toggled }
                        .buttonStyle(.plain)
                        .font(.title3)
                }
                Text(game.t(.paused))
                    .font(.system(.title3, design: .rounded).weight(.bold))
                    .foregroundStyle(Palette.gold)
                Text(game.t(.tapToResume))
                    .font(.caption2)
                    .foregroundStyle(Palette.muted)
                Button(game.t(.menu)) { game.toMenu() }
                    .tint(Palette.gold)
            }
            .padding(.horizontal, 12)
        }
    }
}

struct GameOverOverlay: View {
    @ObservedObject var game: OrbitGame

    var body: some View {
        ZStack {
            Color.black.opacity(0.88).ignoresSafeArea()
            ScrollView {
                VStack(spacing: 6) {
                    Text(game.t(.gameOver))
                        .font(.system(.headline, design: .rounded))
                        .foregroundStyle(Palette.gold)
                    Text("\(game.score)")
                        .font(.system(size: 44, weight: .bold, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(Palette.parchment)
                    Text(game.isNewBest ? game.t(.newBest) : "\(game.t(.best)) \(game.best)")
                        .font(.caption)
                        .foregroundStyle(game.isNewBest ? Palette.gold : Palette.muted)
                    Button {
                        game.start()
                    } label: {
                        Text(game.t(.playAgain)).bold().frame(maxWidth: .infinity)
                    }
                    .tint(Palette.gold)
                    Button(game.t(.menu)) { game.toMenu() }
                        .buttonStyle(.plain)
                        .font(.caption)
                        .foregroundStyle(Palette.muted)
                        .padding(.top, 2)
                }
                .padding(.horizontal, 10)
            }
        }
    }
}
