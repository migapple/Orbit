import Foundation

/// Langue de l'app : suit la montre par défaut, bascule avec le drapeau.
enum Lang: String {
    case fr, en

    static var system: Lang {
        (Locale.preferredLanguages.first ?? "en").hasPrefix("fr") ? .fr : .en
    }

    var flag: String { self == .fr ? "🇫🇷" : "🇬🇧" }
    var toggled: Lang { self == .fr ? .en : .fr }
}

enum TextKey {
    case play, best, gameOver, playAgain, menu, paused, tapToResume, hint, newBest, pauseHint
}

extension Lang {
    func t(_ key: TextKey) -> String {
        switch (key, self) {
        case (.play, .fr):        return "Jouer"
        case (.play, .en):        return "Play"
        case (.best, .fr):        return "Record"
        case (.best, .en):        return "Best"
        case (.gameOver, .fr):    return "Partie terminée"
        case (.gameOver, .en):    return "Game over"
        case (.playAgain, .fr):   return "Rejouer"
        case (.playAgain, .en):   return "Play again"
        case (.menu, .fr):        return "Menu"
        case (.menu, .en):        return "Menu"
        case (.paused, .fr):      return "Pause"
        case (.paused, .en):      return "Paused"
        case (.tapToResume, .fr): return "Touchez pour reprendre"
        case (.tapToResume, .en): return "Tap to resume"
        case (.hint, .fr):        return "Tournez la Couronne pour placer la bonne couleur sous la balle."
        case (.hint, .en):        return "Turn the Crown to put the matching color under the ball."
        case (.newBest, .fr):     return "Nouveau record !"
        case (.newBest, .en):     return "New best!"
        case (.pauseHint, .fr):   return "Appui long : pause"
        case (.pauseHint, .en):   return "Long press: pause"
        }
    }
}
