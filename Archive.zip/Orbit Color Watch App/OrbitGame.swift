import SwiftUI
import Combine
import WatchKit

struct Ball: Identifiable {
    let id = UUID()
    var angle: Double      // direction en degrés (0 = droite, sens horaire)
    var distance: Double   // 0 = centre, 1 = anneau
    var speed: Double      // fraction du rayon par seconde
    let colorIndex: Int
}

enum GameState { case menu, playing, paused, over }

final class OrbitGame: ObservableObject {
    static let segmentCount = 4
    static let maxLives = 3

    @Published var state: GameState = .menu
    @Published var ringAngle: Double = 0
    @Published var balls: [Ball] = []
    @Published var score = 0
    @Published var lives = OrbitGame.maxLives
    @Published var best: Int
    @Published var isNewBest = false
    @Published var lang: Lang {
        didSet { UserDefaults.standard.set(lang.rawValue, forKey: "lang") }
    }

    private var spawnCooldown = 0.0

    init() {
        best = UserDefaults.standard.integer(forKey: "best")
        if let raw = UserDefaults.standard.string(forKey: "lang"), let saved = Lang(rawValue: raw) {
            lang = saved
        } else {
            lang = .system
        }
    }

    func t(_ key: TextKey) -> String { lang.t(key) }

    // MARK: - Difficulté

    /// Environ 2,4 s du centre à l'anneau au début, puis de plus en plus vite.
    private var baseSpeed: Double { min(0.42 + Double(score) * 0.012, 1.1) }

    /// Une balle à la fois, puis deux à partir de 12 points, trois à partir de 30.
    private var maxBalls: Int { score >= 30 ? 3 : (score >= 12 ? 2 : 1) }

    // MARK: - Cycle de partie

    func start() {
        score = 0
        lives = Self.maxLives
        balls = []
        isNewBest = false
        spawnCooldown = 0.5
        state = .playing
    }

    func pause()  { if state == .playing { state = .paused } }
    func resume() { if state == .paused  { state = .playing } }

    func toMenu() {
        balls = []
        state = .menu
    }

    func rotate(by degrees: Double) {
        guard state == .playing else { return }
        ringAngle = Self.normalize(ringAngle + degrees)
    }

    /// Index du segment de l'anneau situé dans la direction donnée.
    func segment(at angle: Double) -> Int {
        let width = 360.0 / Double(Self.segmentCount)
        let relative = Self.normalize(angle - ringAngle)
        return Int(relative / width) % Self.segmentCount
    }

    // MARK: - Boucle de jeu

    func tick(_ dt: Double) {
        guard state == .playing else { return }

        for i in balls.indices {
            balls[i].distance += balls[i].speed * dt
        }

        let arrived = balls.filter { $0.distance >= 1 }
        balls.removeAll { $0.distance >= 1 }
        for ball in arrived {
            resolve(ball)
            if state != .playing { return }
        }

        spawnCooldown -= dt
        let laneClear = balls.allSatisfy { $0.distance > 0.45 }
        if spawnCooldown <= 0, balls.count < maxBalls, laneClear {
            spawn()
        }
    }

    private func spawn() {
        balls.append(Ball(angle: Double.random(in: 0..<360),
                          distance: 0.08,
                          speed: baseSpeed * Double.random(in: 0.9...1.1),
                          colorIndex: Int.random(in: 0..<Self.segmentCount)))
        spawnCooldown = max(0.35, 1.0 - Double(score) * 0.02)
    }

    private func resolve(_ ball: Ball) {
        if segment(at: ball.angle) == ball.colorIndex {
            score += 1
            WKInterfaceDevice.current().play(.click)
            if score > best {
                best = score
                isNewBest = true
                UserDefaults.standard.set(best, forKey: "best")
            }
        } else {
            lives -= 1
            if lives <= 0 {
                balls = []
                state = .over
                WKInterfaceDevice.current().play(.failure)
            } else {
                WKInterfaceDevice.current().play(.retry)
            }
        }
    }

    static func normalize(_ angle: Double) -> Double {
        let r = angle.truncatingRemainder(dividingBy: 360)
        return r < 0 ? r + 360 : r
    }
}
